print("--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
print("		34.Modulos ")
print("--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")

def sumar(op1,op2):
	print("el Resultado de la suma :", op1+op2)

def restar(op1,op2):
	print("el Resultado de la resta :", op1-op2)

def multiplicar(op1,op2):
	print("el Resultado de la multiplicacion :", op1*op2)

def dividir(dividendo,divisor):
	print("el Resultado de la division :", dividendo/divisor)

def potencia(base,exponente):
	print("el Resultado de la potencia :", base**exponente)

def redondear(numero):
	print("el Resultado del redondear :", round(numero))