def potencia(base,exponente):
	print("el Resultado de la potencia :", base**exponente)