from setuptools import setup

setup(
	name="PaqueteCalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Juan",
	author_email="anrko33@gmail.com",
	url="www.google.com",
	packages=["calculos","calculos.redondeo_potencia"]	
	)
